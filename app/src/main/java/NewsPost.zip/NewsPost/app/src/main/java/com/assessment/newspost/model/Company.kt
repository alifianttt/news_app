package com.assessment.newspost.model

data class Company(
    var bs: String?,
    var catchPhrase: String?,
    var name: String?
)