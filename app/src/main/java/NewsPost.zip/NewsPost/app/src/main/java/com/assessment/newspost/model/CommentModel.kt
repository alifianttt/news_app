package com.assessment.newspost.model

data class CommentModel(
    var body: String?,
    var email: String?,
    var id: Int?,
    var name: String?,
    var postId: Int?
)