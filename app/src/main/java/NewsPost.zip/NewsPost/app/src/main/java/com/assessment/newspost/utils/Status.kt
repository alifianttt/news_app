package com.assessment.newspost.utils

enum class Status {
    SUCCES,
    LOADING,
    ERROR
}