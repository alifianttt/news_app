package com.assessment.newspost.model

data class AlbumModel(
    var id: Int?,
    var title: String?,
    var userId: Int?
)