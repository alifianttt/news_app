package com.assessment.newspost.model

data class PhotoModel(
    var albumId: Int?,
    var id: Int?,
    var thumbnailUrl: String?,
    var title: String?,
    var url: String?
)