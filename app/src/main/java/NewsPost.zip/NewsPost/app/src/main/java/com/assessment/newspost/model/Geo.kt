package com.assessment.newspost.model

data class Geo(
    var lat: String?,
    var lng: String?
)