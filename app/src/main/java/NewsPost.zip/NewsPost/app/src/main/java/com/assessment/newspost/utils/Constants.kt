package com.assessment.newspost.utils

object Constants {
    interface CONFIG{
        companion object{
            const val USER_AGENT = "Dalvic/2.1.0 (Linux; U; Android 10; Pixel 3 XL Build/QP1A.191005.007)"//"Mozilla/5.0 (Windows NT 6.3; WOW64; rv:37.0) Gecko/20100101 Firefox/37.0"
        }
    }
}